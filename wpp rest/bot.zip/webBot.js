// Función asíncrona para enviar un mensaje al presionar 'Enter' o hacer clic en un botón
async function sendMessage(event) {
    // Comprobar si la tecla presionada es 'Enter' o el evento es de tipo 'click'
    if (event.key === 'Enter' || event.type === 'click') {
        
        // Obtener el mensaje del campo de entrada y eliminar espacios en blanco al inicio y al final
        const message = document.getElementById('messageInput').value.trim();
        
        // Verificar que el mensaje no esté vacío
        if (!message) {
            alert('Por favor, escribe un mensaje antes de enviar.');
            return; // Detener la ejecución si el campo está vacío
        }

        // Mostrar el mensaje del usuario en el área de conversación
        const conversation = document.getElementById('conversation');
        conversation.innerHTML += `<div class="message user">${message}</div>`;
        
        // Mostrar un mensaje de "Procesando" mientras se espera la respuesta del servidor
        document.getElementById('responseOutput').innerText = "Processing...";

        // Ocultar la sección de bienvenida si aún está visible
        const welcomeSection = document.getElementById('welcomeSection');
        if (welcomeSection) {
            welcomeSection.style.display = 'none';
        }

        try {
            // Enviar el mensaje al servidor usando una solicitud POST
            const response = await fetch('http://22.ip.gl.ply.gg:20927/api/message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: message }),  // Convertir el mensaje a formato JSON
            });

            // Procesar la respuesta JSON del servidor
            const data = await response.json();
            
            // Mostrar la respuesta del bot en el área de conversación si existe
            if (data.response) {
                conversation.innerHTML += `<div class="message bot">${data.response}</div>`;
            } else {
                document.getElementById('responseOutput').innerText = "Error: Respuesta vacía del servidor.";
            }

        } catch (error) {
            // Mostrar mensaje de error en caso de fallo en la solicitud
            console.error('Error sending message:', error);
            document.getElementById('responseOutput').innerText = 'Error: No se pudo enviar el mensaje. Inténtalo más tarde.';
        }

        // Limpiar el campo de entrada de texto y desplazar la vista hacia el final de la conversación
        document.getElementById('messageInput').value = ''; // Limpiar el campo de entrada
        conversation.scrollTop = conversation.scrollHeight; // Desplazar hacia abajo la conversación
    }
}

// Función para enviar un mensaje al hacer clic en un botón con texto predefinido
function sendButtonMessage(message) {
    // Establecer el valor del campo de entrada de texto con el mensaje del botón
    document.getElementById('messageInput').value = message;
    
    // Llamar a la función sendMessage simulando un evento de 'click'
    sendMessage({ type: 'click' });
}
