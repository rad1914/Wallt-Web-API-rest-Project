// Text to type in the title
const titleText = "¿Qué tienes en mente?";
const writingTitle = document.getElementById('writingTitle');
let index = 0;

function typeTitle() {
    if (index < titleText.length) {
        writingTitle.textContent += titleText.charAt(index);
        index++;
        setTimeout(typeTitle, 28); // Adjust typing speed here (30 ms per character)
    }
}

// JavaScript to trigger button and image animations on page load
document.addEventListener("DOMContentLoaded", function() {
    const buttons = document.querySelectorAll('.animate-button');
    const image = document.querySelector('.animate-image');

    // Animate the image
    if (image) {
        image.classList.add('fadeInImage');
    }

    // Animate buttons with a staggered effect
    buttons.forEach((button, index) => {
        setTimeout(() => {
            button.classList.add('fadeInButton');
        }, index * 200); // Delay for each button
    });

    // Start typing the title after the image animation
    setTimeout(typeTitle, 500); // Delay to start typing after image animation
});
